---
title: 'Seifert'
date: 2017-08-06T23:24:43+02:00
---

<!-- {{% mediablock havid="qnje34" class="image left" %}} -->

The HAV collection of Jan Seifert consists mainly of field work photography from Nagaland, India beginning in early 2008 up to today. Attached as a photographer to the Research projects »Material Culture, Oral Traditions and Identity among the Naga in Northeast-India« and »Audiovisual Documentation of the Making and Installation of a Logdrum (Chang Naga, Northeast India)« of the Völkerkundemuseum der Universität Zürich and since 2010 independently, he traveled Nagaland extensively and began his own research on local material culture and migration in 2012. His photographic interests in the area are widespread – daily life in its social and techical aspects as well as documentation of change, be it landscapes or ways of life. The materials – a selection from over 50000 photographs so far, recorded and transcribed interviews and other notes – will be incorporated gradually, starting with the photographs.

### Featured Archive Entries

<!-- {{% mediablock havid="af3k4e" %}}
{{% mediablock havid="zh98hr" %}} -->
