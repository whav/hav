import React from 'react'

const Image = () => (
  <img
    src={'https://source.unsplash.com/random/800x600'}
    alt="something from unsplash"
  />
)

export default Image
