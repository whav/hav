---
title: 'Imprint'
date: 2017-08-07T00:33:01+02:00
---

## Himalaya Archive Vienna (HAV)

_at the_  
**Center for Interdisciplinary Research and Documentation of Inner and South Asian Cultural History (CIRDIS)**  
Department for South Asian, Tibetan and Buddhist Studies  
Spitalgasse 2-4, Hof 2.1  
A-1090 Vienna, Austria

## Layout

Jan Seifert and Jürgen Schörflinger (CIRDIS)

## Technical Realisation

Jürgen Schörflinger (CIRDIS)

## Responsibility for contents

All content presented in the HAV has been compiled carefully. The HAV and its contributors make no guarantees of accuracy, completeness and timeliness of the informations provided and therefore accept no responsibility or liability for damages or losses resulting from the use of this website. Links to external websites have been chosen carefully. As they are outside the control of the HAV, it accepts no responsibility for these sites.

## Technical Support

If you experience technical problems, please send an e-mail to the [hav@univie.ac.at](mailto: hav@univie.ac.at).
