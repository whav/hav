export {
  FiFile as FileIcon,
  FiImage as ImageIcon,
  FiFolder as FolderIcon,
} from 'react-icons/fi';
